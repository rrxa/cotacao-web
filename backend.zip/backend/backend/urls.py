from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),  # Rota para o painel administrativo
    path('api/', include('cotacao.urls')),  # Inclui as rotas da aplicação 'cotacao'
]
