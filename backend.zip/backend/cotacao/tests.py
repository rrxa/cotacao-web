from django.test import TestCase
from .models import Parametro

class ParametroTestCase(TestCase):
    def setUp(self):
        Parametro.objects.create(nome="Frete", valor=50.00)

    def test_parametro_criado(self):
        parametro = Parametro.objects.get(nome="Frete")
        self.assertEqual(parametro.valor, 50.00)
