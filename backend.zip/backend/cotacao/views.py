from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Parametro, Cidade

def listar_parametros(request):
    """
    Retorna uma lista de parâmetros cadastrados no banco de dados.
    """
    parametros = Parametro.objects.select_related('destino').values(
        "destino__nome", "tarifa", "tarifa_minima", "coleta_desc", "entrega_desc"
    )
    return JsonResponse(list(parametros), safe=False)

def detalhes_cidade(request, iata):
    """
    Retorna os detalhes de uma cidade pelo código IATA.
    """
    cidade = get_object_or_404(Cidade, iata=iata)
    dados = {
        "nome": cidade.nome,
        "uf": cidade.uf,
        "iata": cidade.iata,
        "tipo": cidade.tipo,
        "prazo": cidade.prazo
    }
    return JsonResponse(dados)
