from django.contrib import admin
from .models import Parametro, Cidade

admin.site.register(Parametro)
admin.site.register(Cidade)
