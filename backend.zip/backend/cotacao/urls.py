from django.urls import path
from .views import listar_parametros, detalhes_cidade

urlpatterns = [
    path('parametros/', listar_parametros, name="listar_parametros"),
    path('cidade/<str:iata>/', detalhes_cidade, name="detalhes_cidade"),
]
