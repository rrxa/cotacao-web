import React from "react";

const Servicos = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Serviços Úteis</h1>
      <p>Em breve, você encontrará aqui links e serviços úteis.</p>
    </div>
  );
};

export default Servicos;
