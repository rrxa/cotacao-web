import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Bem-vindo ao Cotação Web</h1>
      <p>Faça cotações de forma rápida e fácil.</p>
    </div>
  );
};

export default Home;
